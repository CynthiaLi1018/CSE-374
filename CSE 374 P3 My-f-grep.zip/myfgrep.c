// Copyright 2020 Cynthia Li
// CSE 374 HW3 Myfgrep
// 1839952

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Limit the maximum characters in input line
#define LINE_MAX 502
// Limit the maximum characters in string pattern
#define PATTERN_MAX 101

// flags indicating whether option "-i" "-n" is given:
// 1 as given, 0 ohterwise.
int i_option = 0;
int n_option = 0;


int count_flags(char *argv[]);
void arg_number_check(int argc, int flag_number, char *argv[]);
void usage(char *argv[]);

// parameter: argument list
// return: flag number
// function: check whether the 2nd and 3rd arguments are options,
// if it they are, update option status and increment flag number.
int count_flags(char *argv[]) {
  int flag_number = 0;
  for (int i = 1; i < 3; i++) {
    if (strncmp(&argv[i][0], "-", 1) == 0) {
      flag_number++;
      if (strncmp(argv[i], "-n", 2) == 0) {
        n_option = 1;
      } else if (strncmp(argv[i], "-i", 2) == 0) {
        i_option = 1;
      }
    }
  }
  return flag_number;
}

// parameter: number of args, flag number, args list
// check whether the command line has sufficient argument input
// if wrong number is given, program exit with EXIT_FAILURE
void arg_number_check(int argc, int flag_number, char *argv[]) {
  if (argc - flag_number < 3) {
    usage(argv);
    exit(EXIT_FAILURE);
  }
}

// Paramter: arg list
// print out the usage message
void usage(char *argv[]) {
  printf("%s [OPTIONS] pattern file...\n", argv[0]);
}

// paramter: file, pattern, i_option, n_option
// parse through the given file and print out the lines that matches
// with given pattern in format depending on i_option and n_option.
// **THIS METHOD PROBABALY CAN BE SIMPLIED BY USING fgets()
void print_matches_in_file(FILE *file, char *pattern,
int i_option, int n_option) {
  int  line_n, i, k;
  char line[LINE_MAX];
  char compare[LINE_MAX];
  char char_line;

  line_n = 1;  // to track the line number

  // parse through the file line by line
  while (!feof(file)) {
    i = 0;
    // copying one line character by character
    char_line = fgetc(file);
    while (char_line != '\n') {
      line[i] = char_line;
      i++;
      if (feof(file)) {
        break;
      }
      char_line = fgetc(file);
    }

      line[i] = char_line;  // make end of line "\n"
      i++;
      line[i] = '\0';  // make end of line "\n\0"


    if (feof(file)) {
      break;
    }

    // deal with case insensitive situation
    // convert copied lines to lowercase
    if (i_option) {
       k = 0;
       while (line[k] != '\0') {
         compare[k] = tolower(line[k]);
         k++;
       }
    } else {  // deal with case sensitive situation
      snprintf(compare, i+1, "%s", line);
    }

    // check for whether the copied and potentially converted to
    // case-insensitive line matches with the given pattern
    // exclude the case that the line is "\n"
    if ((strstr(compare, pattern) != NULL) && (i != 0)) {
      if (n_option) {
        printf("(%d) %s", line_n, line);
      } else {
        printf("%s", line);
      }
    }
    line_n++;
    for (k = 0; k < i+1; k++) {
      compare[k]='\0';
    }
  }
}

// parameter: flag number, args number, args list, pattern, i_option,
// n_option parse through file name list, check existence of file, if
// not existing, print out error message, if existing, print out file
// name and lines matches with the given pattern in each file.
void print_all_matches(int flag_number, int argc, char *argv[],
char *pattern, int i_option, int n_option) {
  char *file_name;
  // locate file name list in the arg list
  // and parse through the file name list
  for (int i = flag_number+2; i < argc; i++) {
    file_name = argv[i];
    FILE *file = fopen(file_name, "r");
    // check for file existence
    if (file == NULL) {  // print out error message to stderr
                         // if file doesn't exist
      fprintf(stderr, "Could not open file: %s\n", file_name);
    } else {
      printf("%s:\n", file_name);
      print_matches_in_file(file, pattern, i_option, n_option);
    }
  }
}

// parameter: arg number, arg list
// return: exit code
// the program will exit with EXIT_SUCCESS if no error occurs
int main(int argc, char *argv[]) {
  int flag_number, i;
  char* pattern;

  // get the flag number and check for arg number to prevent
  // wrong usage
  flag_number = 0;
  pattern = "";
  arg_number_check(argc, flag_number, argv);
  flag_number = count_flags(argv);
  arg_number_check(argc, flag_number, argv);

  // get the pattern and change it to lower case if i-option is applied
  pattern = argv[flag_number + 1];
  if (i_option) {
    i = 0;
    while (pattern[i] != '\0') {
      pattern[i] = tolower(pattern[i]);
      i++;
    }
  }

  print_all_matches(flag_number, argc, argv, pattern, i_option, n_option);

  return(EXIT_SUCCESS);
}
