#include <vector>
#include <iostream>
#include <fstream>

#include "Expr.h"
#include "helpers.h"

using namespace std;
using namespace expr;

// For each x in xs, substitute it in for x in the equation fx and evaluate
vector<double> plot(const shared_ptr<Expr>& fx, vector<double> xs);

// Over write file with filename as a CSV file where each row has an x,y
void write_file(string filename, ExprPtr equation,
                const map<string, double>& values,
                const vector<double>& xs);

int main(int argc, char** argv) {
    // A list of evenly spaced x points from -5 to 5
    vector<double> xs;
    for(double d = -5; d <= 5; d += 0.1) {
        xs.push_back(d);
    }

    // Plots a line using y = mx + b
    ExprPtr line = var("m") * var("x") + var("b");
    cout << "Equation: " << line << endl;

    // Set slope to 0.5 and y intercept to 3
    map<string, double> values = {{"m", 0.5}, {"b", 3}};
    write_file("line.csv", line, values, xs);

    // TODO: Plot a curve using y = mx^2 + b where m = 0.5, b = 3
    //      It should be written into a file called "curve.csv"
    //      It should use the same `xs` variable as above
    ExprPtr exp1, exp2;
    exp1 = var("x") ^ num(2);
    exp2 = exp1 * var("m") + var("b");
    write_file("curve.csv", exp2, values, xs);
}

void write_file(string filename, ExprPtr equation,
                const map<string, double>& values,
                const vector<double>& xs) {
    // Overwrite file
    ofstream file(filename);

    ExprPtr subst = equation->setVariables(values);
    auto ys = plot(subst, xs);

    auto x_it = xs.begin();
    auto y_it = ys.begin();
    while (x_it != xs.end()) {
        file << *x_it << "," << *y_it << endl;
        x_it++;
        y_it++;
    }
    // Automatically closes file when destructor is called
}

vector<double> plot(const shared_ptr<Expr>& fx, vector<double> xs) {
    vector<double> ys;
    for (double x : xs) {
        auto subst = fx->setVariables({{"x", x}});
        ys.push_back(subst->evaluate());
    }
    return ys;
}