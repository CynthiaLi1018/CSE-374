#! /bin/bash
# Cynthia Li
# 1839952
# HW1: Problem 2

if [ $# -lt 2 ]; then
   echo "usage: ./search.sh filename query..."
   exit 0
fi

if [ ! -f $1 ]; then
   echo "File does not exist"
   exit 1
fi

FILE_NAME=$1
shift
TOTAL=0
  
while [ $# -gt 0 ]
do
   COUNT=$(grep -o -F "$1" "$FILE_NAME" | wc -l)
   echo "$1: $COUNT"
   TOTAL=$(($TOTAL + $COUNT))
   shift
done

echo "$TOTAL Total"
