#! /bin/bash
# Cynthia LI
# 1839952
# HW1: Prolbem #1
# This program aims to sort people's names alphabetically by their last name

if [ $# -lt 1 ]; then
   echo "$0 needs requires at least 1 argument" <& 1
fi

if [ ! -f $1 ]; then
   echo "File does not exist" <& 1
   exit 1
fi

cat <$@ | cut -d " " -f 2 | sort
